import { SpriteAsset, GameObject, RoomData } from '../types';

// ==========================================
//   GORGEOUS RETRO PIXEL ART BASE64 ASSETS
// ==========================================

// P1 Blue Knight Hero (16x16)
const PLAYER_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAm0lEQVR42mNkoBAwUqiegaEFCbMDbYCp6OicB6mGgNlhYkCDI8gCVAXIdshmIDvRFmD1E69hiAFA9pMtwGoAhgXY8mIuBvPAbMClGGIAvAGkYvIKgBggGUA0AHpWfP0C6gFUAtAGYgMkA7AGoA1D9QuIAaQCogxADmP8v+8/WUD0wS+4ALvBqOECgUGoAQKBYRYDAgCgI2f5iYfSygAAAABJRU5ErkJggg==';

// P2 Red-Orange Knight Hero (16x16)
const COOP_PLAYER_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAmklEQVR42mNkoBAwUqiegaEFCbMDbYCp6OicB6mGgNlhYkCDI8gCVAXIdshmIDvRFmD1E69hiAFA9pMtwGoAhgXY8mIuBvPAbMClGGIAvAGkYvIKgBggGUA0AHpWfP1i6gFUAtAGYgMkA7AGoA1D9QuIAaQCogxADmP8f6A/WUD0wS+4ALvBqOECgUGoAQKBYRYDAgByBmf5YjZfLgAAAABJRU5ErkJggg==';

// Medieval Dark Stone Brick with highlight lines (16x16)
const GROUND_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAZ0lEQVR42mNkoBAwUqiegaEFIZfDQLQCvBaAhVEMAGkBsgW4FOC0gLgCYAtwKWA4A8gNIDVAUoFQA0gFIBXgUADXAtwWYFfA8AyQLMClgKECfApwKYA+BlALMBxAegIYA9IDDAwALqf+X7j2ZtYAAAAASUVORK5CYII=';

// Glowing Red Lava/Demon Block (16x16)
const LAVA_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAbElEQVR42mNkoBAwUqiegaEFuRz2ohfgtQCsjGIASAuQLcClAKcFxBVAWIAsADVAUgFIBTgU4FQAs+PZFTC8AyQLcClgqACfAlgKYFvOaAGpBWBWICVAcoCJAekBBoYI1gRkAIYHGJiRnoChAAAu8fWf7m+hYgAAAABJRU5ErkJggg==';

// Green Slime Monster / Ghost (16x16)
const ENEMY_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAYElEQVR42mNkoBAwUqiegaEFxBUEsCkgTgF+BXgVENYgC0AUkFMAUUBMw8DAgKgCrAqkKqAqoKhAdD0gKYDkBrwGIIcx/N/2n6IDkBxAcoBfAY4E8gNMD8gNDAwRDAwA5pY8z9L7nEIAAAAASUVORK5CYII=';

// Shimmering Golden Coin (16x16)
const ITEM_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAYElEQVR42mNkoBAwUqiegaEFyRXYizYArAUMDAyIFmCzABsDCDsA6QpYgIsB6AoYGBgQTUBWAVYFYhVAdD0gKUAuBrwGIIcx5N/+n6IDkBxAcoBfAY4E8gNMD8gNDAwRDAwAwVdNzxt9x7EAAAAASUVORK5CYII=';

// Shiny Red Heart for Health Powerup (16x16)
const HEART_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAY0lEQVR42mNkoBAwUqiegaEFTB7GohWAmYAtgGoAMQGRAbYgC1ANgGvArUBSA2AD8CqAmgA2AGQCsimgKEDWB2ICkhpQfRirAWQ9MAsYGBgQPQGMAekBBgYGFmQDIAYMDAAtBfe5bY94sAAAAABJRU5ErkJggg==';

// Dungeon Gold Key (16x16)
const KEY_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAaklEQVR42mNkoBAwUqiegaEF2RSYizeAnQvAALkWgAAmBqgCkBbAGsBpASEGYAuwWYCNAcoAsAIWA6AV0FSAKAuIDZAUICUAPgboFiBpALECpAYIBYgNQI8BLmOAbgGyAcQGDAyEGjAwAAAnpP8v9qD+JgAAAABJRU5ErkJggg==';

// Iron-bound Oakwood Prison Door (16x16)
const DOOR_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAZElEQVR42mNkoBAwUqiegaEFIZfDQLQCvBYQC0AWIDYALIDLAmIBpAEoFpALQBeAbgGhBeQD0AXEFsDFAHYBcQtILYCJAewC4hYgGYBHAckC3AqIDgHBAK0AsQHCE8AYkB5gYAD3GfeY0450iQAAAABJRU5ErkJggg==';

// Mystic Swirling Portal/Trophy Goal (16x16)
const GOAL_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAb0lEQVR42mNkoBAwUqiegaEFpRxWpRfgtQCsDGwBUgNgBQAxQGqAsAArALMAsQHICiAsQBUgpAArALMAsQEoCpAUgKMAm4+JBiAZgE8BsQE2H9MCmBhIDSDqAVzGAPX/wbyYgYEBsQHCE8AYkB5gYAAZ9fc3XhFf5wAAAABJRU5ErkJggg==';

// Glowing Magic Cyan Bullet (16x16)
const BULLET_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAALklEQVR42mNkoBAwUqiegaEFbAzEgDgFpCoAF8BrAL8CHHHIgCwAUUAn8Z9gDAD9mPnffj6v9gAAAABJRU5ErkJggg==';

// Medieval Epic Blue Castle (32x32)
const CASTLE_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAh0lEQVR42u2WsQ2AMBAEZ8gUiSgZpWOkp6b0Y4RIHAsQIiEaX9gUvsuvXqY7gUIIY8A3YpW/6p8RszZpT6g9D8/C2g7ZgE56AsXAnvQMmIeXQDHIgYfADrQEmgPNAF8CxcCe9AyYh5dAMciBh8AOtASaA80AXwLFwJ70DJiHlyAz6A68/p5A8/KqK+o0f7U7f68MAAAAAElFTkSuQmCC';

// Spiky Dark Obsidian Enemy Castle (32x32)
const ENEMY_CASTLE_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAh0lEQVR42u2WsQ2AMBAEZ8iUiCgZpWOkp6b0Y8RICAsQIkI0vrApfJdfvUx3AoUQxoBvxCp/1T8jZm3SnlB7Hp6FtR2yAZ30BIqBPeoZMA8vgWKQAw+BHWgJNAeaAb4EioE96RkwDy+BYpADD4EdaAk0B5oBvgSKgT3pGfArP686TqA7f/X89f66mD/0W3+zM3+3CwAAAABJRU5ErkJggg==';

// Chibi Allied Soldier with spear (16x16)
const SOLDIER_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAmUlEQVR42mNkoBAwUqiegaEFCbMDbYCp6OicB6mGgNlhYkCDI8gCVAXIdshmIDvRFmD1E69hiAFA9pMtwGoAhgXY8mIuBvPAbMClGGIAvAGkYvIKgBggGUA0AHpWfP0C6gFUAtAGYgMkA7AGoA1D9QuIAaQCogxADmP8v+8/WUD0wS+4ALvBqOECgUGoAQKBYRYDAgCgI2f5iYfSygAAAABJRU5ErkJggg==';

// Angry Green Enemy Orc (16x16)
const ORC_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAm0lEQVR42mNkoBAwUqiegaEFCbMDbYCp6OicB6mGgNlhYkCDI8gCVAXIdshmIDvRFmD1E69hiAFA9pMtwGoAhgXY8mIuBvPAbMClGGIAvAGkYvIKgBggGUA0AHpWfP1i6gFUAtAGYgMkA7AGoA1D9QuIAaQCogxADmP8f6A/WUD0wS+4ALvBqOECgUGoAQKBYRYDAgByBmf5YjZfLgAAAABJRU5ErkJggg==';

// High-tech Glowing Cyan Paddle (32x8)
const PADDLE_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAICAAYAAADr6f0qAAAAGUlEQVR42mNkoBAwUqiegaF6qHp6qHpSAQDwUADL/NqY8gAAAABJRU5ErkJggg==';

// Bright Neon White Energy Ball (8x8)
const BALL_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAYAAAD86bEAAAAAGUlEQVR42mNkoBAwUqiegaF6qHp6qHpSAQDwUADL/NqY8gAAAABJRU5ErkJggg==';

// Classic Arcade Wall Brick with yellow highlight lines (16x16)
const BRICK_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAZ0lEQVR42mNkoBAwUqiegaEFIZfDQLQCvBaAhVEMAGkBsgW4FOC0gLgCYAtwKWA4A8gNIDVAUoFQA0gFIBXgUADXAtwWYFfA8AyQLMClgKECfApwKYA+BlALMBxAegIYA9IDDAwALqf+X7j2ZtYAAAAASUVORK5CYII=';

// Deep Starry Galactic Sky (32x32)
const SKY_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAgAAAgCAYAAABzenr0AAAAZklEQVR42mNkoBAwUqiegaEFIZfDQLQCvBaAhVEMAGkBsgW4FOC0gLgCYAtwKWA4A8gNIDVAUoFQA0gFIBXgUADXAtwWYFfA8AyQLMClgKECfApwKYA+BlALMBxAegIYA9IDDAwACNn9n7TepbYAAAAASUVORK5CYII=';

// Endless Runner Player Dino/Fox (32x32)
const RUNNER_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAtCAYAAAAgJgIUAAABUUlEQVR4nO1YIRLCMBBsGRQKUR2D6SOqEKgKnoBAo/qCKgQKgUKg0BXVKARPiAATXY0FRXOZuZuklBlWdFV6vSQ7e7nZtHEkIEnUS3rXBU1jYl/O6Bcb9QUECUcqWoJ0fWEnNEbbfJV6N9DHuZ0rlAZCCQgS45CkdDkjT3as9cOGdfQ1IJQYSHwwkPggqDt09fAn9QCEEhAkYsmy65r3jqLyL7pb8vE8530EQgkIEk53SCWgkKycxqOIt3i6fp7P22MAoQQEiTE9pVQiKd1q3+02RSF1BAWEEhAkRO+gMpbloR2fjc2hHbHJ+LkhgFACgoRTDnp6h8/AfyDoZqWOhX1Y1P6cjoBQAoKEUw7aESc1aeOZStjJt+e2HV97kIBQAoKE2B1SCdwblJBvDJsjAUIJCBLiPyuKe6a8C02rK+s7g3d0gShVHysPKQEFhBIQJN6Cbl9YR0wbLgAAAABJRU5ErkJggg==';

// Desert Spikey Cactus Obstacle (16x32)
const CACTUS_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAoCAYAAAD6xArmAAAA/klEQVR4nO2WLRLCMBCFvzIcIRodXYVAcwg050BwDjSHQCNQ6Ojq3AEEXQa2XfozJDAMn+ym29eX7WsKDNzCXQD82gMQdgGAeIyFdc8jkz6LxjDVF7TSWMVRjdMpFoV90estz9N7LJ760gEQzs/eWvVAuEBTeb6p0EqH1oVkigtrKvQcx0O70vxTYT1RdvuunFr512WF5veyQsj/5cnuN5TUHlt1QWdGMsWNxr509wRro6tuNn4XZlYIbnlTZ2WFJrnHZlb0VeLfFPxb/xvbJ82LaTeNc/pskIrOW1XAIRQvbzR+xkA880e+OjZrVYqiiy63ii9x8LQv7aQzeMr0ppxuBNLH+IAAAAASUVORK5CYII=';

// Cave Flying Winged Bat Obstacle (32x16)
const BAT_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAeCAYAAAC49JeZAAABFklEQVR4nNVYIRKDMBAMnShq0dWoCp6AqKqu6GMQ6D4ChegT+ojYotHR2NalSyc3yQ0V3VVHIJedvU1yQ1GW5ctEsCxLERtHSHMlbMmJc3eaRf8FlKQtPvTNPcSdu4Qy5ZS1aU7RceceSRJoiS8O0e8plaYkbaUXW6zivU8uLFkiB5RKU5IW7TH5KcSSVbSQLIFr1VWdzEOpNCVp0R4Sroc+xOPchXgwcGJUn/A4x+duAaXSlKSz7IG7W8I5fZ+oc0qgVJqStMVeAi8O7U5/Drfo+L5tVXmwHZX6HEqlKUmvTg8sxzh3KqtobYDASyqn9aVUmpJ0shTGrFvKX/UPWksgKJWmJK0qizH6X2EStJZAUCpNSfoNTKdkh6ky9KEAAAAASUVORK5CYII=';


export const getStandaloneAssets = () => ({
  player: PLAYER_B64,
  playerCoop: COOP_PLAYER_B64,
  ground: GROUND_B64,
  lava: LAVA_B64,
  enemy: ENEMY_B64,
  item: ITEM_B64,
  runner: RUNNER_B64,
  cactus: CACTUS_B64,
  bat: BAT_B64,
  coin_gold: ITEM_B64,
  heart: HEART_B64,
  sky: SKY_B64,
  key: KEY_B64,
  door: DOOR_B64,
  goal: GOAL_B64,
  bullet: BULLET_B64,
  soldier: SOLDIER_B64,
  orc: ORC_B64,
  castle: CASTLE_B64,
  enemy_castle: ENEMY_CASTLE_B64,
  paddle: PADDLE_B64,
  ball: BALL_B64,
  brick: BRICK_B64
});

export const getStarterLevel = (): RoomData => ({
  id: 'rm_starter',
  width: 16,
  height: 15,
  map: [
    ...new Array(16 * 10).fill(0), // empty top
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
  ],
  settings: {
    name: 'rm_starter',
    caption: 'Starter Room',
    speed: 30,
    lives: 3,
    persistent: false,
    clearView: true,
    creationCode: '',
    tileAnimSpeed: 250,
    enableViews: false,
    snapX: 16,
    snapY: 16,
    bgColor: '#111122',
    drawBgColor: true
  },
  backgrounds: Array(8).fill(null).map(() => ({ visible: false, foreground: false, source: null, tileH: true, tileV: true, stretch: false, x: 0, y: 0, hspeed: 0, vspeed: 0 })),
  views: Array(8).fill(null).map(() => ({ visible: false, viewX: 0, viewY: 0, viewW: 256, viewH: 240, portX: 0, portY: 0, portW: 256, portH: 240, followObj: null, hBorder: 32, vBorder: 32, hSpeed: -1, vSpeed: -1 }))
});
