
import * as React from 'react';
import { useRef, useState, useEffect } from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, RotateCcw, Maximize2, Minimize2 } from 'lucide-react';

interface ConsoleViewerProps {
  mode: 'code' | 'game' | 'art';
  content: string;
  title: string;
}

const ConsoleViewer: React.FC<ConsoleViewerProps> = ({ mode, content, title }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeKeys, setActiveKeys] = useState<Record<string, boolean>>({});
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Function to inject keyboard events into the iframe
  const sendKey = (key: string, type: 'keydown' | 'keyup') => {
    if (!iframeRef.current || !iframeRef.current.contentWindow) return;
    
    let code = '';
    let keyCode = 0;

    switch(key) {
        case 'ArrowUp': code = 'ArrowUp'; keyCode = 38; break;
        case 'ArrowDown': code = 'ArrowDown'; keyCode = 40; break;
        case 'ArrowLeft': code = 'ArrowLeft'; keyCode = 37; break;
        case 'ArrowRight': code = 'ArrowRight'; keyCode = 39; break;
        case 'z': code = 'KeyZ'; keyCode = 90; break;
        case 'x': code = 'KeyX'; keyCode = 88; break;
        case 'Enter': code = 'Enter'; keyCode = 13; break;
        case 'Shift': code = 'ShiftLeft'; keyCode = 16; break;
    }

    const iwin = iframeRef.current?.contentWindow;
    if (!iwin) return;

    const event = new KeyboardEvent(type, {
      key: key,
      code: code,
      keyCode: keyCode,
      bubbles: true,
      cancelable: true,
      view: iwin
    });
    
    // Dispatch to multiple targets to ensure the game engine catches it
    iwin.dispatchEvent(event);
    const canvas = iwin.document?.querySelector('canvas');
    if (canvas) canvas.dispatchEvent(event);
    if (iwin.document?.body) iwin.document.body.dispatchEvent(event);
  };

  const handleBtnDown = (e: React.PointerEvent, key: string) => {
    e.preventDefault();
    e.stopPropagation();
    // Only trigger if not already active
    if (!activeKeys[key]) {
        setActiveKeys(prev => ({...prev, [key]: true}));
        sendKey(key, 'keydown');
    }
  };

  const handleBtnUp = (e: React.PointerEvent, key: string) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveKeys(prev => ({...prev, [key]: false}));
    sendKey(key, 'keyup');
  };

  // Ensure iframe has focus for keyboard input when game mode starts
  useEffect(() => {
    if (mode === 'game' && iframeRef.current) {
        iframeRef.current.focus();
    }
  }, [mode]);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        console.error("Error entering full screen:", err);
      });
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  return (
    <div className="flex flex-col w-full h-full">
      <div 
        ref={containerRef}
        className={`group relative bg-black overflow-hidden transition-all duration-200 ${
          isFullscreen 
            ? 'w-screen h-screen border-0 rounded-none z-[99999]' 
            : 'w-full aspect-[4/3] rounded-lg border-4 border-gray-800 shadow-[0_0_20px_rgba(0,0,0,0.8)]'
        }`}
      >
        {/* Toggle Fullscreen floating button */}
        {mode === 'game' && (
          <button
            onClick={toggleFullscreen}
            className="absolute top-2 left-2 z-[60] p-2 bg-black/60 hover:bg-black/90 text-white rounded border border-white/20 transition-all opacity-0 group-hover:opacity-100 cursor-pointer"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen Mode"}
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
        )}

        {/* TV Bezel Effect */}
        <div className="absolute inset-0 pointer-events-none z-20 border-[2px] border-white/5 rounded-lg shadow-inner"></div>
        
        {/* Scanlines */}
        <div className="absolute inset-0 pointer-events-none z-10 crt-overlay"></div>
        
        <div className="w-full h-full relative z-0 flex flex-col">
          {mode === 'code' && (
             <div className="w-full h-full bg-[#0000AA] p-4 overflow-auto font-mono text-xs text-white/90">
               <h3 className="text-center mb-4 text-yellow-300 font-pixel border-b-2 border-white/20 pb-2">
                 SOURCE CODE: {title}
               </h3>
               <pre className="whitespace-pre-wrap leading-relaxed select-text font-mono">
                 {content}
               </pre>
             </div>
          )}

          {mode === 'art' && (
            <div className="w-full h-full flex items-center justify-center bg-gray-900">
              <img src={content || undefined} alt="Box Art" className="max-h-full max-w-full object-contain" />
            </div>
          )}

          {mode === 'game' && (
            <iframe 
              ref={iframeRef}
              srcDoc={content}
              title="NES Emulator"
              className="w-full h-full border-none bg-black focus:outline-none"
              sandbox="allow-scripts allow-same-origin allow-pointer-lock allow-downloads allow-forms allow-modals allow-popups allow-presentation allow-top-navigation allow-fullscreen"
              allowFullScreen={true}
            />
          )}
        </div>

        {/* Screen Glare */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-white/5 to-transparent rounded-bl-full pointer-events-none z-30"></div>
      </div>

      {/* Android Touch Controls - Enhanced for Playability */}
      {mode === 'game' && (
        <div className="mt-4 select-none touch-none" style={{ touchAction: 'none' }} dir="ltr">
          <div className="grid grid-cols-2 gap-4">
            
            {/* D-Pad Area */}
            <div className="flex items-center justify-center p-4 bg-gray-800/80 rounded-2xl border-2 border-gray-700 shadow-lg">
              <div className="grid grid-cols-3 gap-1">
                {/* UP */}
                <div className="col-start-2">
                    <button 
                    className={`w-14 h-14 rounded-t-lg flex items-center justify-center transition-all border-b border-gray-900 ${activeKeys['ArrowUp'] ? 'bg-gray-500 translate-y-1' : 'bg-gray-700 shadow-[0_4px_0_#1f2937]'}`}
                    onPointerDown={(e) => handleBtnDown(e, 'ArrowUp')}
                    onPointerUp={(e) => handleBtnUp(e, 'ArrowUp')}
                    onPointerLeave={(e) => activeKeys['ArrowUp'] && handleBtnUp(e, 'ArrowUp')}
                    onContextMenu={(e) => e.preventDefault()}
                    style={{ touchAction: 'none' }}
                    >
                    <ChevronUp className="w-8 h-8 text-gray-300" />
                    </button>
                </div>
                
                {/* LEFT */}
                <div className="col-start-1 row-start-2">
                    <button 
                    className={`w-14 h-14 rounded-l-lg flex items-center justify-center transition-all border-r border-gray-900 ${activeKeys['ArrowLeft'] ? 'bg-gray-500 translate-y-1' : 'bg-gray-700 shadow-[0_4px_0_#1f2937]'}`}
                    onPointerDown={(e) => handleBtnDown(e, 'ArrowLeft')}
                    onPointerUp={(e) => handleBtnUp(e, 'ArrowLeft')}
                    onPointerLeave={(e) => activeKeys['ArrowLeft'] && handleBtnUp(e, 'ArrowLeft')}
                    onContextMenu={(e) => e.preventDefault()}
                    style={{ touchAction: 'none' }}
                    >
                    <ChevronLeft className="w-8 h-8 text-gray-300" />
                    </button>
                </div>

                {/* CENTER (Decor) */}
                <div className="row-start-2 bg-gray-800 rounded-full flex items-center justify-center">
                    <div className="w-4 h-4 bg-black/50 rounded-full"></div>
                </div>

                {/* RIGHT */}
                <div className="col-start-3 row-start-2">
                    <button 
                    className={`w-14 h-14 rounded-r-lg flex items-center justify-center transition-all border-l border-gray-900 ${activeKeys['ArrowRight'] ? 'bg-gray-500 translate-y-1' : 'bg-gray-700 shadow-[0_4px_0_#1f2937]'}`}
                    onPointerDown={(e) => handleBtnDown(e, 'ArrowRight')}
                    onPointerUp={(e) => handleBtnUp(e, 'ArrowRight')}
                    onPointerLeave={(e) => activeKeys['ArrowRight'] && handleBtnUp(e, 'ArrowRight')}
                    onContextMenu={(e) => e.preventDefault()}
                    style={{ touchAction: 'none' }}
                    >
                    <ChevronRight className="w-8 h-8 text-gray-300" />
                    </button>
                </div>

                {/* DOWN */}
                <div className="col-start-2 row-start-3">
                    <button 
                    className={`w-14 h-14 rounded-b-lg flex items-center justify-center transition-all border-t border-gray-900 ${activeKeys['ArrowDown'] ? 'bg-gray-500 translate-y-1' : 'bg-gray-700 shadow-[0_4px_0_#1f2937]'}`}
                    onPointerDown={(e) => handleBtnDown(e, 'ArrowDown')}
                    onPointerUp={(e) => handleBtnUp(e, 'ArrowDown')}
                    onPointerLeave={(e) => activeKeys['ArrowDown'] && handleBtnUp(e, 'ArrowDown')}
                    onContextMenu={(e) => e.preventDefault()}
                    style={{ touchAction: 'none' }}
                    >
                    <ChevronDown className="w-8 h-8 text-gray-300" />
                    </button>
                </div>
              </div>
            </div>

            {/* Action Buttons Area */}
            <div className="flex flex-col justify-between p-4 bg-gray-800/80 rounded-2xl border-2 border-gray-700 shadow-lg relative">
                
                {/* A / B Buttons */}
                <div className="flex items-center justify-center gap-6 mt-2">
                    <div className="flex flex-col items-center gap-2 translate-y-4">
                        <button 
                            className={`w-16 h-16 rounded-full border-2 border-red-900 flex items-center justify-center transition-all ${activeKeys['x'] ? 'bg-red-500 translate-y-1 shadow-none' : 'bg-red-600 shadow-[0_4px_0_#7f1d1d]'}`}
                            onPointerDown={(e) => handleBtnDown(e, 'x')}
                            onPointerUp={(e) => handleBtnUp(e, 'x')}
                            onPointerLeave={(e) => activeKeys['x'] && handleBtnUp(e, 'x')}
                            onContextMenu={(e) => e.preventDefault()}
                            style={{ touchAction: 'none' }}
                        >
                            <span className="font-pixel text-white text-xl drop-shadow-md">B</span>
                        </button>
                    </div>
                    <div className="flex flex-col items-center gap-2 -translate-y-2">
                        <button 
                            className={`w-16 h-16 rounded-full border-2 border-red-900 flex items-center justify-center transition-all ${activeKeys['z'] ? 'bg-red-500 translate-y-1 shadow-none' : 'bg-red-600 shadow-[0_4px_0_#7f1d1d]'}`}
                            onPointerDown={(e) => handleBtnDown(e, 'z')}
                            onPointerUp={(e) => handleBtnUp(e, 'z')}
                            onPointerLeave={(e) => activeKeys['z'] && handleBtnUp(e, 'z')}
                            onContextMenu={(e) => e.preventDefault()}
                            style={{ touchAction: 'none' }}
                        >
                            <span className="font-pixel text-white text-xl drop-shadow-md">A</span>
                        </button>
                    </div>
                </div>

                {/* Start / Select Buttons */}
                <div className="flex gap-4 justify-center mt-6">
                    <div className="flex flex-col items-center">
                        <button 
                           className={`w-16 h-8 border-2 border-gray-600 rounded-full transform rotate-12 mb-1 transition-all ${activeKeys['Shift'] ? 'bg-gray-600' : 'bg-gray-900'}`}
                           onPointerDown={(e) => handleBtnDown(e, 'Shift')}
                           onPointerUp={(e) => handleBtnUp(e, 'Shift')}
                           onPointerLeave={(e) => activeKeys['Shift'] && handleBtnUp(e, 'Shift')}
                           onContextMenu={(e) => e.preventDefault()}
                           style={{ touchAction: 'none' }}
                        ></button>
                        <span className="text-[9px] tracking-widest text-gray-400 font-pixel">SELECT</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <button 
                           className={`w-16 h-8 border-2 border-gray-600 rounded-full transform rotate-12 mb-1 transition-all ${activeKeys['Enter'] ? 'bg-gray-600' : 'bg-gray-900'}`}
                           onPointerDown={(e) => handleBtnDown(e, 'Enter')}
                           onPointerUp={(e) => handleBtnUp(e, 'Enter')}
                           onPointerLeave={(e) => activeKeys['Enter'] && handleBtnUp(e, 'Enter')}
                           onContextMenu={(e) => e.preventDefault()}
                           style={{ touchAction: 'none' }}
                        ></button>
                        <span className="text-[9px] tracking-widest text-gray-400 font-pixel">START</span>
                    </div>
                </div>

                {/* Reset Button */}
                <div className="absolute top-2 right-2">
                    <button 
                        onClick={() => {
                            if (iframeRef.current) {
                                const currentSrcDoc = iframeRef.current.srcdoc;
                                iframeRef.current.srcdoc = '';
                                setTimeout(() => {
                                    if (iframeRef.current) iframeRef.current.srcdoc = currentSrcDoc;
                                }, 10);
                            }
                        }}
                        className="w-8 h-8 bg-gray-900 border-2 border-gray-700 rounded-full flex items-center justify-center hover:bg-gray-800 active:bg-gray-700 transition-all"
                        title="Reset Console"
                    >
                        <RotateCcw className="w-4 h-4 text-red-500" />
                    </button>
                    <div className="text-[7px] text-center text-gray-500 font-pixel mt-1">RESET</div>
                </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConsoleViewer;
