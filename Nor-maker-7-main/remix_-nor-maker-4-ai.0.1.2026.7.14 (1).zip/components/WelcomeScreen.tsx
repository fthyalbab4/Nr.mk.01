
import React, { useState, useRef } from 'react';
import { Folder, Upload, Globe, Package, Gamepad2, Wand2, HardDrive, Rocket, Mic, Image as ImageIcon, X, Target, Waypoints, Zap, MessageSquare, TreePine, Eye, User, ArrowDown, Car, Glasses, Smartphone, File, ChevronRight, Trash2 } from 'lucide-react';
import RetroButton from './RetroButton';

const WelcomeScreen = ({ prompt, setPrompt, isListening, handleVoiceInput, handleGenerate, handleCreateOffline, selectedImage, setSelectedImage, onImageSelect, imageInputRef, gmkInputRef, handleOpenGmk, gmxFolderInputRef, handleOpenGmx, htmlInputRef, handleOpenHtml, nesInputRef, savedTemplates, handleLoadSavedTemplate, handleDeleteSavedTemplate, handleDeleteMultipleSavedTemplates, handleImportNor }: any) => {
    const [wizardTab, setWizardTab] = useState<'ai' | 'local' | 'recent'>('ai');
    const [localTemplate, setLocalTemplate] = useState<string>('hollowknight');
    const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);
    const norInputRef = useRef<HTMLInputElement>(null);

    const toggleTemplateSelection = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        setSelectedTemplates(prev =>
            prev.includes(id) ? prev.filter(tId => tId !== id) : [...prev, id]
        );
    };

    return (
        <div className="w-full h-full bg-zinc-100 p-2 sm:p-4 flex items-center justify-center font-sans overflow-y-auto">
            <div className="w-full max-w-2xl bg-[#EBE7DD] border border-zinc-400 shadow-[6px_6px_0_rgba(0,0,0,0.1)] flex flex-col rounded-sm overflow-hidden my-auto">
                {/* Header */}
                <div className="h-8 bg-[#D3CEB8] border-b border-zinc-400 text-zinc-800 flex items-center px-3 font-bold text-xs justify-between">
                    <span>صفحة البداية - Start Page</span>
                    <div className="flex gap-1">
                        <button className="w-5 h-5 bg-[#EBE7DD] border border-zinc-500 flex items-center justify-center font-bold text-[10px]">_</button>
                        <button onClick={() => handleCreateOffline('blank')} title="إغلاق وفتح مشروع فاضي" className="w-5 h-5 bg-[#EBE7DD] border border-zinc-500 flex items-center justify-center font-bold text-[10px]">X</button>
                    </div>
                </div>

                {/* Content */}
                <div className="p-4 space-y-4">
                    {/* Hero Title */}
                    <div className="text-center space-y-1">
                        <h1 className="text-2xl font-bold font-serif italic text-zinc-900">NOR MAKER <span className="text-sm not-italic font-sans">8.2</span></h1>
                        <p className="text-xs text-zinc-600">أهلاً بك في صانع الألعاب - ابدأ مشروعك الآن!</p>
                    </div>

                    {/* Import Buttons */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        <input type="file" ref={norInputRef} className="hidden" onChange={(e) => {
                          if (e.target.files && e.target.files[0]) { handleImportNor(e.target.files[0]); }
                        }} />
                        <button onClick={() => norInputRef.current?.click()} className="flex items-center gap-2 p-2 bg-orange-100 border border-orange-300 text-orange-900 text-xs font-bold hover:bg-orange-200">
                            <Folder size={14}/> استيراد NOR
                        </button>
                        <button onClick={() => gmkInputRef.current?.click()} className="flex items-center gap-2 p-2 bg-yellow-100 border border-yellow-300 text-yellow-900 text-xs font-bold hover:bg-yellow-200">
                            <Upload size={14}/> استيراد GM 8.2
                        </button>
                        <button onClick={() => htmlInputRef.current?.click()} className="flex items-center gap-2 p-2 bg-green-100 border border-green-300 text-green-900 text-xs font-bold hover:bg-green-200">
                            <Globe size={14}/> استيراد HTML
                        </button>
                        <button onClick={() => gmxFolderInputRef.current?.click()} className="flex items-center gap-2 p-2 bg-purple-100 border border-purple-300 text-purple-900 text-xs font-bold hover:bg-purple-200">
                            <Package size={14}/> استيراد gmx
                        </button>
                        <button onClick={() => nesInputRef.current?.click()} className="flex items-center gap-2 p-2 bg-red-100 border border-red-300 text-red-900 text-xs font-bold hover:bg-red-200">
                            <Gamepad2 size={14}/> استيراد NES ROM
                        </button>
                    </div>

                    {/* Tabs section */}
                    <div className="border border-zinc-400 bg-[#E0DCC8] flex flex-col">
                        {/* Tab buttons */}
                        <div className="flex bg-[#D3CEB8] border-b border-zinc-400">
                            <button onClick={() => setWizardTab('ai')} className={`px-3 py-1 text-xs border-r border-zinc-400 flex items-center gap-1 ${wizardTab === 'ai' ? 'bg-[#E0DCC8] font-bold' : 'hover:bg-zinc-200'}`}>
                                <Wand2 size={11} className="text-purple-600"/> Cloud Wizard (AI)
                            </button>
                            <button onClick={() => setWizardTab('local')} className={`px-3 py-1 text-xs border-r border-zinc-400 flex items-center gap-1 ${wizardTab === 'local' ? 'bg-[#E0DCC8] font-bold' : 'hover:bg-zinc-200'}`}>
                                <HardDrive size={11} className="text-blue-600"/> Manual Project
                            </button>
                            <button onClick={() => setWizardTab('recent')} className={`px-3 py-1 text-xs border-r border-zinc-400 flex items-center gap-1 ${wizardTab === 'recent' ? 'bg-[#E0DCC8] font-bold' : 'hover:bg-zinc-200'}`}>
                                <Folder size={11} className="text-amber-600"/> Saved Templates
                            </button>
                        </div>

                        {/* Tab content */}
                        <div className="bg-white border-t-0 p-3 min-h-[200px] max-h-[340px] overflow-y-auto">

                            {/* AI Tab */}
                            {wizardTab === 'ai' && (
                                <div className="space-y-2">
                                    <p className="text-[10px] text-zinc-500">اكتب فكرة لعبتك أو ارفع صورة لتوليد لعبة مشابهة...</p>
                                    <div className="relative">
                                        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} className="w-full h-24 p-2 border border-zinc-400 text-xs resize-none focus:outline-none focus:border-blue-400" placeholder="مثال: لعبة منصات بطلها روبوت..." dir="auto" />
                                        <div className="absolute bottom-2 left-2 flex gap-1">
                                            <button onClick={handleVoiceInput} className={`p-1.5 rounded-full border text-xs ${isListening ? 'bg-red-100 border-red-400 text-red-600 animate-pulse' : 'bg-gray-100 border-gray-300 text-gray-600 hover:bg-blue-50'}`} title="صوت">
                                                <Mic size={12}/>
                                            </button>
                                            <button onClick={() => onImageSelect()} className={`p-1.5 rounded-full border text-xs ${selectedImage ? 'bg-green-100 border-green-400 text-green-600' : 'bg-gray-100 border-gray-300 text-gray-600 hover:bg-blue-50'}`} title="صورة">
                                                <ImageIcon size={12}/>
                                            </button>
                                        </div>
                                    </div>
                                    {selectedImage && (
                                        <div className="relative w-full h-16 bg-gray-100 border border-dashed border-gray-300 flex items-center justify-center overflow-hidden group">
                                            <img src={selectedImage || undefined} className="h-full object-contain" alt="selected"/>
                                            <button onClick={() => setSelectedImage(null)} className="absolute top-1 right-1 bg-red-500 text-white p-0.5 rounded-full opacity-0 group-hover:opacity-100"><X size={9}/></button>
                                        </div>
                                    )}
                                    <RetroButton onClick={handleGenerate} className="w-full justify-center font-bold text-xs !bg-zinc-800 text-white" disabled={!prompt && !selectedImage}>
                                        Create Game <Rocket size={12} className="ml-1 inline"/>
                                    </RetroButton>
                                </div>
                            )}

                            {/* Manual / Local Templates Tab */}
                            {wizardTab === 'local' && (
                                <div className="flex flex-col gap-3">
                                    <p className="text-[10px] text-gray-500">اختر قالباً جاهزاً لبدء مشروعك بدون AI.</p>
                                    <div className="flex flex-col gap-0.5">
                                        {[
                                            { id: 'starter',       icon: <Package size={14} className="text-blue-600"/>,   bg: 'bg-blue-100 border-blue-300',   label: 'Classic Platformer (ألعاب منصات / مغامرات جانبية)', desc: 'منصات كلاسيكية مع جاذبية وقفز وأعداء.' },
                                            { id: 'rpg',           icon: <MessageSquare size={14} className="text-yellow-600"/>, bg: 'bg-yellow-100 border-yellow-300', label: 'RPG Adventure (ألعاب تقمص أدوار / استكشاف ومتاهة)',  desc: 'حوارات، تحكم بالشخصية، وتفاعل علوي.' },
                                            { id: 'shooter',       icon: <Target size={14} className="text-red-600"/>,      bg: 'bg-red-100 border-red-300',     label: 'Top-Down Shooter (ألعاب إطلاق نار / فضاء وأركيد)',    desc: 'حركة ثمانية اتجاهات مع إطلاق نار مستمر.' },
                                            { id: 'runner',        icon: <Zap size={14} className="text-orange-600"/>,      bg: 'bg-orange-100 border-orange-300', label: 'Endless Runner (ألعاب جري لانهائي وتفادي عقبات)',   desc: 'لعبة متكاملة مع قوائم ومنطق جري لا نهائي.' },
                                            { id: 'maze',          icon: <Waypoints size={14} className="text-green-600"/>, bg: 'bg-green-100 border-green-300', label: 'Simple Puzzle Game (ألعاب ألغاز وتحدي ذكاء)',  desc: 'متاهة مع مفاتيح وأبواب وأهداف ذكية.' },
                                            { id: 'fighter',       icon: <Target size={14} className="text-orange-600"/>,   bg: 'bg-orange-100 border-orange-300', label: 'Street Brawler (ألعاب قتال وتلاحم)',           desc: 'لعبة قتال مع حركات وذكاء اصطناعي.' },
                                            { id: 'racing',        icon: <Zap size={14} className="text-green-600"/>,       bg: 'bg-green-100 border-green-300', label: 'Top-Down Racing (ألعاب سباقات وسرعة)',   desc: 'انزلاق وسباق سيارات بسرعة عالية.' },
                                            { id: 'strategy',      icon: <Waypoints size={14} className="text-purple-600"/>, bg: 'bg-purple-100 border-purple-300', label: 'Real-Time Strategy (ألعاب استراتيجية وتخطيط)', desc: 'جمع موارد، بناء جيش، وتدمير قاعدة العدو.' },
                                            { id: 'arcade',        icon: <Zap size={14} className="text-pink-600"/>,        bg: 'bg-pink-100 border-pink-300',     label: 'Classic Arcade (ألعاب أركيد كلاسيكية / طوب)', desc: 'لعبة كسر قوالب الطوب الكلاسيكية مع فيزياء ارتداد.' },
                                            { id: 'megaman',       icon: <Zap size={14} className="text-blue-600"/>,        bg: 'bg-blue-100 border-blue-300',   label: 'Mega Action (ميجا مان)',           desc: 'منصات مع إطلاق نار وعداد حياة.' },
                                            { id: 'hollowknight',  icon: <Gamepad2 size={14} className="text-gray-700"/>,   bg: 'bg-gray-200 border-gray-400',   label: 'Hollow Knight Style (فارس مجوف)', desc: 'منصات مع قتال بالسيوف وزعماء.' },
                                            { id: 'platformer_pro',icon: <Rocket size={14} className="text-purple-600"/>,   bg: 'bg-purple-100 border-purple-300', label: 'Platformer Pro (منصات متقدم)',   desc: 'قفز مزدوج، انزلاق جدار، وفيزياء متقدمة.' },
                                            { id: 'sonic',         icon: <Zap size={14} className="text-blue-600"/>,        bg: 'bg-blue-100 border-blue-300',   label: 'Sonic Style (سرعة فائقة)',        desc: 'سرعة عالية، حلقات، وجمع خواتم.' },
                                            { id: 'adventure_island', icon: <TreePine size={14} className="text-green-700"/>, bg: 'bg-green-100 border-green-300', label: 'Adventure Island (جزيرة المغامرة)', desc: 'ثلاث مراحل مع زعيم نهائي.' },
                                            { id: 'first_person',  icon: <Eye size={14} className="text-blue-600"/>,        bg: 'bg-blue-100 border-blue-300',   label: 'First Person 3D (منظور أول)',     desc: 'عرض ثلاثي الأبعاد من منظور اللاعب.' },
                                            { id: 'third_person',  icon: <User size={14} className="text-green-600"/>,      bg: 'bg-green-100 border-green-300', label: 'Third Person 3D (منظور ثالث)',    desc: 'عرض ثلاثي الأبعاد خلف اللاعب.' },
                                            { id: 'top_down',      icon: <ArrowDown size={14} className="text-yellow-600"/>, bg: 'bg-yellow-100 border-yellow-300', label: 'Top Down (منظور علوي)',         desc: 'منظور علوي كلاسيكي.' },
                                            { id: 'vehicle',       icon: <Car size={14} className="text-red-600"/>,         bg: 'bg-red-100 border-red-300',     label: 'Vehicle (مركبات)',                desc: 'قيادة مركبات بفيزياء واقعية.' },
                                            { id: 'ar',            icon: <Smartphone size={14} className="text-purple-600"/>, bg: 'bg-purple-100 border-purple-300', label: 'AR (الواقع المعزز)',           desc: 'قالب الواقع المعزز.' },
                                            { id: 'vr',            icon: <Glasses size={14} className="text-indigo-600"/>,  bg: 'bg-indigo-100 border-indigo-300', label: 'VR (الواقع الافتراضي)',         desc: 'قالب الواقع الافتراضي.' },
                                            { id: 'handheld_ar',   icon: <Smartphone size={14} className="text-pink-600"/>, bg: 'bg-pink-100 border-pink-300',   label: 'Handheld AR (AR محمول)',          desc: 'تجربة AR للأجهزة المحمولة.' },
                                            { id: 'blank',         icon: <File size={14} className="text-gray-600"/>,       bg: 'bg-gray-100 border-gray-300',   label: 'Blank Project',                   desc: 'غرفة فارغة بدون أصول. ابن من الصفر.' },
                                        ].map(({ id, icon, bg, label, desc }) => (
                                            <label key={id} className={`flex items-center gap-3 cursor-pointer p-2 border ${localTemplate === id ? 'bg-blue-50 border-blue-300' : 'hover:bg-gray-50 border-transparent'}`}>
                                                <input type="radio" name="tpl" checked={localTemplate === id} onChange={() => setLocalTemplate(id)} className="shrink-0"/>
                                                <div className={`w-7 h-7 border flex items-center justify-center rounded shrink-0 ${bg}`}>{icon}</div>
                                                <div>
                                                    <div className="font-bold text-[9px] text-black">{label}</div>
                                                    <div className="text-[9px] text-gray-500">{desc}</div>
                                                </div>
                                            </label>
                                        ))}

                                        {/* User-saved templates section */}
                                        {savedTemplates && savedTemplates.length > 0 && (
                                            <>
                                                <div className="font-bold text-[10px] text-gray-700 mt-2 mb-1 px-2 flex justify-between items-center border-t border-gray-200 pt-2">
                                                    <span>Saved Templates (قوالب محفوظة)</span>
                                                    {selectedTemplates.length > 0 && (
                                                        <button onClick={(e) => { e.stopPropagation(); handleDeleteMultipleSavedTemplates(selectedTemplates); setSelectedTemplates([]); }} className="text-red-600 flex items-center gap-1 text-[9px] bg-red-100 px-2 py-0.5 rounded border border-red-300">
                                                            <Trash2 size={9}/> حذف المحدد ({selectedTemplates.length})
                                                        </button>
                                                    )}
                                                </div>
                                                {savedTemplates.map((t: any) => (
                                                    <label key={t.id} className={`flex items-center gap-3 cursor-pointer p-2 border ${localTemplate === t.id ? 'bg-blue-50 border-blue-300' : 'hover:bg-gray-50 border-transparent'}`}>
                                                        <input type="checkbox" checked={selectedTemplates.includes(t.id)} onClick={(e) => toggleTemplateSelection(e, t.id)} onChange={() => {}} className="shrink-0"/>
                                                        <input type="radio" name="tpl" checked={localTemplate === t.id} onChange={() => setLocalTemplate(t.id)} className="shrink-0"/>
                                                        <div className="w-7 h-7 bg-purple-100 border border-purple-300 flex items-center justify-center rounded shrink-0"><Folder size={14} className="text-purple-600"/></div>
                                                        <div className="flex items-center justify-between w-full">
                                                            <div>
                                                                <div className="font-bold text-[9px] text-black">{t.name || 'Untitled'}</div>
                                                                <div className="text-[9px] text-gray-500">{new Date(t.savedAt).toLocaleDateString()}</div>
                                                            </div>
                                                            {localTemplate === t.id && (
                                                                <button onClick={(e) => { e.stopPropagation(); handleDeleteSavedTemplate(t.id); }} className="p-1 hover:bg-red-200 rounded text-red-600"><Trash2 size={12}/></button>
                                                            )}
                                                        </div>
                                                    </label>
                                                ))}
                                            </>
                                        )}
                                    </div>
                                    <div className="flex justify-end pt-1 border-t border-zinc-300">
                                        <RetroButton onClick={() => {
                                            if (savedTemplates?.find((t: any) => t.id === localTemplate)) {
                                                handleLoadSavedTemplate(localTemplate);
                                            } else {
                                                handleCreateOffline(localTemplate);
                                            }
                                        }} className="px-6 h-8 font-bold w-full justify-center text-xs">
                                            Create Project <ChevronRight size={12} className="ml-1 inline"/>
                                        </RetroButton>
                                    </div>
                                </div>
                            )}

                            {/* Saved Templates Tab */}
                            {wizardTab === 'recent' && (
                                <div className="space-y-1">
                                    {savedTemplates?.map((t: any) => (
                                        <button key={t.id} onClick={() => handleLoadSavedTemplate(t.id)} className="w-full text-left p-2 hover:bg-zinc-100 text-xs border-b border-zinc-100 flex items-center gap-2">
                                            <Folder size={12} className="text-purple-500 shrink-0"/>
                                            <span className="flex-1">{t.name || 'Untitled Template'}</span>
                                            <span className="text-[9px] text-gray-400">{new Date(t.savedAt).toLocaleDateString()}</span>
                                        </button>
                                    ))}
                                    {(!savedTemplates || savedTemplates.length === 0) && (
                                        <div className="flex flex-col items-center justify-center h-32 text-gray-400 gap-2">
                                            <Folder size={28}/>
                                            <p className="text-xs italic">لا توجد قوالب محفوظة حالياً.</p>
                                            <p className="text-[10px] text-gray-400">استخدم File → Save as Template لحفظ مشروعك.</p>
                                        </div>
                                    )}
                                </div>
                            )}

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WelcomeScreen;
