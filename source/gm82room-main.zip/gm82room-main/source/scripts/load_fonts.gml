fontmap=dsmap()
