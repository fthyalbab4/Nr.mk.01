var dx2,dy2;

tooltiptext=""

if (mode==0) {
    //object tab tooltips
    posx=0
    posy=0
    if (mouse_wy>120 && mouse_wy<height-136) for (i=0;i<objects_length;i+=1) if (objloaded[i]) {
        dx=20+40*posx
        dy=140+40*posy+palettescroll
        if (point_in_rectangle(mouse_wx,mouse_wy,dx-20,dy-20,dx+20,dy+20)) {
            w=sprite_get_width(objspr[i])
            h=sprite_get_height(objspr[i])
            dx2=dx dy2=dy
            if (w>32 || h>32) {
                dx2=floor(max(1,dx-w/2)+w/2)+frac(w/2)
                dy2=floor(max(1,dy-h/2)+h/2)+frac(h/2)
                draw_set_color_sel() d3d_fog_trick(draw_get_color()) draw_set_color($ffffff)
                draw_sprite_stretched_ext(objspr[i],0,dx2-w/2+1,dy2-h/2+1,w,h,0,1)
                draw_sprite_stretched_ext(objspr[i],0,dx2-w/2+1,dy2-h/2-1,w,h,0,1)
                draw_sprite_stretched_ext(objspr[i],0,dx2-w/2-1,dy2-h/2+1,w,h,0,1)
                draw_sprite_stretched_ext(objspr[i],0,dx2-w/2-1,dy2-h/2-1,w,h,0,1)
                d3d_fog_trick()
            }
            draw_sprite_stretched(objspr[i],0,dx2-w/2,dy2-h/2,w,h)
            if (keyboard_check(vk_alt)) draw_sprite(sprMenuButtons,52-objshow[i],dx+8,dy+8)
            hot=unpick(i,objhotbar[1],objhotbar[2],objhotbar[3],objhotbar[4],objhotbar[5],objhotbar[6],objhotbar[7],objhotbar[8],objhotbar[9])
            if (hot>=0) draw_sprite(sprMinesweeper,hot,dx,dy)
            tooltiptext=ds_list_find_value(objects,i)+objprops[i]
            if (objdesc[i]!="") tooltiptext=tooltiptext+lf+lf+objdesc[i]
        }
        posx+=1 if (posx=4) {posx=0 posy+=1}
    }

    if (paltooltip==1) tooltiptext="Add more..."
    if (paltooltip==2) tooltiptext="Clean list"

    //bottom panel
    draw_button_ext(0,height-112,160,112,1,global.col_main)
}

if (mode==0) {
    with (Instancepanel) if (point_in_rectangle(mouse_wx,mouse_wy,x+w-32,32,x+w,64) && !mouse_check_button(mb_left)) other.tooltiptext="Drag to resize"
}
if (mode==1) {
    with (Tilepanel) if (point_in_rectangle(mouse_wx,mouse_wy,x+w-36,y,x+w,y+36) && !mouse_check_button(mb_left)) other.tooltiptext="Drag to resize"

    if (bgnametooltip!="") tooltiptext=bgnametooltip
}

draw_knob()

with (Button) button_draw()
with (Button) if (focus && alt!="" && (tagmode==mode || tagmode==-1)) drawtooltip(alt)

if (mousein && mode==0) {
    with (select) {
        if (fieldactive) {
            draw_instance_fields(0)
        } else if (abs(global.mousex-fieldhandx)<9*zm && abs(global.mousey-fieldhandy)<9*zm) {
            draw_instance_fields(1)
        }
    }
    if (keyboard_check(ord("C"))) {
        with (instance) if (abs(global.mousex-fieldhandx)<9*zm && abs(global.mousey-fieldhandy)<9*zm || other.focus==id && !fieldactive) {
            draw_instance_fields(1)
        }
    } else {
        with (focus) if (!fieldactive) {
            draw_instance_fields(1)
        }
    }
}

with (colorpicker) event_draw()

if (mode==1 and tilebgpal!=noone) if (bg_tilemode[tilebgpal] and mousein) {
    if (tilemap_complete==0) tooltiptext="Cannot Smart Paint with#incomplete Smart Tile mappings"
    if (tilemap_complete==-1) tooltiptext="Cannot Smart Paint with#incorrectly mapped tiles"
}

if (tooltiptext!="") drawtooltip(tooltiptext)
