globalvar theme,buttontex,themebutton;
