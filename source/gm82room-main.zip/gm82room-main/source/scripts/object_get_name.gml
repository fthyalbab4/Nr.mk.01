return argument0
