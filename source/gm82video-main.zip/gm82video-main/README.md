# Game Maker 8.2 Video
Extension for Game Maker 8.2 to allow video playback onto surfaces through a custom codec format.

Requires 8.2 Core, Buffer, DirectX9 and either Sound or Audio.

Requires an ffmpeg.exe binary to use the encoder tool.
