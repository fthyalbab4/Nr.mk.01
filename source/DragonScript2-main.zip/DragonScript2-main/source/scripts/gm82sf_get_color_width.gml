return line_width
